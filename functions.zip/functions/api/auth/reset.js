// functions/api/auth/reset.js
import { sha256Base64Url } from '../../lib/tokens.js';
import { pbkdf2Hash } from '../../lib/auth.js';
import { passwordPolicyError } from '../../lib/validators.js';

export async function onRequest({ request, env }) {
  const db = env.POSTS_DB;
  if (request.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });

  let token = '', password = '';
  try {
    const body = await request.json();
    token = String(body.token || '');
    password = String(body.password || '');
  } catch {}

  const policyErr = passwordPolicyError(password);
  if (!token || policyErr) {
    return new Response(JSON.stringify({ error: !token ? 'Invalid token.' : policyErr }), {
      status: 400, headers: { 'Content-Type': 'application/json' }
    });
  }

  const tokenHash = await sha256Base64Url(token);
  const nowIso = new Date().toISOString();

  const rec = await db.prepare(`
    SELECT pr.id, pr.user_id, pr.expires_at, pr.used
    FROM password_resets pr
    WHERE pr.token_hash = ?
    LIMIT 1
  `).bind(tokenHash).first();

  if (!rec || rec.used) {
    return new Response(JSON.stringify({ error: 'Invalid or used token.' }), {
      status: 400, headers: { 'Content-Type': 'application/json' }
    });
  }
  if (rec.expires_at <= nowIso) {
    return new Response(JSON.stringify({ error: 'Token expired.' }), {
      status: 400, headers: { 'Content-Type': 'application/json' }
    });
  }

  // Update password
  const saltBytes = new Uint8Array(16); crypto.getRandomValues(saltBytes);
  const saltB64 = btoa(String.fromCharCode(...saltBytes));
  const hashB64 = await pbkdf2Hash(password, saltB64, 100000, 32);

  await db.prepare(`
    UPDATE users
       SET password_algo = 'pbkdf2-sha256',
           password_salt = ?,
           password_hash = ?
     WHERE id = ?
  `).bind(saltB64, hashB64, rec.user_id).run();

  // mark token used
  await db.prepare(`UPDATE password_resets SET used = 1 WHERE id = ?`).bind(rec.id).run();

  // return the user's email so the client can auto-login
  const u = await db.prepare(`SELECT email FROM users WHERE id = ?`).bind(rec.user_id).first();
  return new Response(JSON.stringify({ ok: true, email: u?.email || null }), {
    headers: { 'Content-Type': 'application/json' }
  });
}
